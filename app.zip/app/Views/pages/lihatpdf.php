<div class="modal fade" id="disetujuiModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #2E179D; color: White; ">
                <embed type="application/pdf" data-toggle="modal" data-target="#disetujuiModal" src="/filePendukung/<?= $preview['namafile']; ?>" width="100%" height="100%"></embed>
            </div>
        </div>
    </div>
</div>